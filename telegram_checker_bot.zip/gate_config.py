# ==================== إعدادات بوابات الدفع ====================

# ---------- PayPal Commerce ----------
PAYPAL_API_URL = "http://151.247.197.54:5500/paypal"
PAYPAL_DEFAULT_URL = "https://www.northidahowaterpolo.org/donations/donation-form/"
PAYPAL_DEFAULT_PRICE = "1"

# ---------- Stripe Auth ----------
STRIPE_API_URL = "http://151.247.197.54:5000/tome"
STRIPE_DEFAULT_URL = "https://dominileather.com"

# ---------- PayPal GiveWP ----------
GIVEWP_DEFAULT_URL = "https://example.org"
GIVEWP_DEFAULT_AMOUNT = 0.05

ALTERNATIVE_URLS = [
    "https://cardamomclub.com.au",
    "https://atlanticbiznet.ca",
    "https://perfectedparticles.co.uk",
    "http://shop.conequipmentparts.com",
    "http://havilahcastle.com",
    "http://southendschoolwear.com"
]