import random
import requests
import base64
import re
import urllib3
from user_agent import generate_user_agent
from requests_toolbelt.multipart.encoder import MultipartEncoder

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class DonationChecker:
    def __init__(self, website_url, donation_amount):
        self.session = requests.Session()
        self.user_agent = generate_user_agent()
        self.base_url = website_url.rstrip('/')
        self.donation_page = f'{self.base_url}/donations/'
        self.min_amount = '0.01'
        self.donation_amount = str(donation_amount)

    def generate_random_name(self):
        first_names = ["James","John","Robert","Michael","William","David","Richard","Joseph","Thomas","Charles"]
        last_names = ["Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis","Rodriguez","Martinez"]
        return random.choice(first_names), random.choice(last_names)

    def generate_email(self, first_name, last_name):
        domains = ['gmail.com','yahoo.com','hotmail.com','outlook.com']
        return f"{first_name.lower()}{last_name.lower()}{random.randint(100,999)}@{random.choice(domains)}"

    def parse_credit_card(self, cc_data):
        parts = cc_data.strip().split("|")
        card_number = parts[0]
        month = parts[1]
        year = parts[2]
        cvv = parts[3].strip()
        if "20" in year:
            year = year.split("20")[1]
        return card_number, month, year, cvv

    def get_page_data(self):
        headers = {'user-agent': self.user_agent}
        response = self.session.get(self.donation_page, headers=headers)
        form_data = {}
        id_form1_match = re.search(r'name="give-form-id-prefix" value="(.*?)"', response.text)
        if id_form1_match:
            form_data['id_form1'] = id_form1_match.group(1)
        id_form2_match = re.search(r'name="give-form-id" value="(.*?)"', response.text)
        if id_form2_match:
            form_data['id_form2'] = id_form2_match.group(1)
        nonec_match = re.search(r'name="give-form-hash" value="(.*?)"', response.text)
        if nonec_match:
            form_data['nonec'] = nonec_match.group(1)
        enc_match = re.search(r'"data-client-token":"(.*?)"', response.text)
        if enc_match:
            enc = enc_match.group(1)
            dec = base64.b64decode(enc).decode('utf-8')
            access_token_match = re.search(r'"accessToken":"(.*?)"', dec)
            if access_token_match:
                form_data['access_token'] = access_token_match.group(1)
        return form_data

    def check_card(self, cc_data):
        try:
            card_number, month, year, cvv = self.parse_credit_card(cc_data)
            first_name, last_name = self.generate_random_name()
            email = self.generate_email(first_name, last_name)
            form_data = self.get_page_data()
            return "Checked (demo response)"
        except Exception as e:
            return f"ERROR: {str(e)}"